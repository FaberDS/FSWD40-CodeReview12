<!DOCTYPE html>
<html <?php language_attributes(); ?>>
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
   <meta name="description" content="<?php bloginfo('description'); ?>">
    <meta name="author" content="<?php bloginfo('author');?>">
    <link rel="icon" href="../../favicon.ico">

    <title><?php bloginfo('name'); ;?>|
    <?php is_front_page() ? bloginfo('description') : wp_title();?>
     <?php wp_title();?></title>

   <title><?php bloginfo('name'); ?></title>
   <!-- Bootstrap core CSS -->
   <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
   <link href="<?php bloginfo('template_url'); ?>/css/style.css" rel="stylesheet">
   <!-- Custom styles for this template -->
   <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
   <?php wp_head(); ?>
 </head>
 <body>
     <div class="container-fluid">
            <div id="nav-containter">
                <?php
                        
                wp_nav_menu( array(
                    'menu'              => 'primary',
                    'theme_location'    => 'primary',
                    'depth'              => 2,
                    'fallback_cb'        => false,
                        'container'         => 'nav'
                    )
                );
            ?>
            </div>
            <div id="wrapper">
          