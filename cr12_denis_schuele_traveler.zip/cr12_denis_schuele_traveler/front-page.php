<?php get_header();?>

    <div class="jumbotron jumbotron-fluid" id="hero">
        <div class="container">
            <h1 class="display-3 text-center head-line">Mount Everest Adventure</h1>
            <p class="lead text-center head-line-2">Your travelling blog, where you dreams become thrue</p>
        </div>
    </div>
    
<div class="container-fluid">
    <section class="boxes divider">
    <div class="container">
        <div class="row">
            <div class="col-md-4 widge">
                
                    <?php if(is_active_sidebar('box1')) : ?>
                        <?php dynamic_sidebar('box1');?>
                    <?php endif;?>
                
            </div>
             <div class="col-md-4 widge">
               
                    <?php if(is_active_sidebar('box2')) : ?>
                        <?php dynamic_sidebar('box2');?>
                    <?php endif;?>
            
            </div>
             <div class="col-md-4 widge">
              
                    <?php if(is_active_sidebar('box3')) : ?>
                        <?php dynamic_sidebar('box3');?>
                    <?php endif;?>
              
            </div>
             
        </div>
    </div>
   </section>

    <div class="row divider">
        <div class="col-12 text-center section-header">
            <h4>Some of our experiences</h4>
        </div>
        <div class="col-md-10 content mx-auto center-block text-center">
           
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/mountain.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/peru.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/snow.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/isle.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/norway.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/canyon.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/beach.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/irland.jpg">
            <img class="box-shadow"src="<?php bloginfo("template_url");?>/img/alps.jpg">
        
    
        </div>
    </div>
     <div class="row divider">
        <div class="col-12 text-center section-header">
            <h4>Our Services</h4>
        </div>
        <div class="col-md-10  widges-container mx-auto center-block text-center">
           <figure class="box-shadow">
               <i class="far fa-map"></i>
               <figcaption>Maps for each continent</figcaption>
           </figure>
           <figure class="box-shadow">
               <i class="fas fa-globe"></i>
               <figcaption>Globaly Service Hotline</figcaption>
           </figure>
           <figure class="box-shadow">
               <i class="fas fa-plane"></i>
               <figcaption>Flight observation</figcaption>
           </figure>
            
    
        </div>
    </div>

</div>
    
<?php get_footer();?>

